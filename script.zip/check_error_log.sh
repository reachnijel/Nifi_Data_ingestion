#!/bin/bash

# Author: MANULIFE
# Date: 2017-08-08

# Description:  Executing sqoop job from Nifi Node

# USAGE: check_job_id.sh <local_file_absolute_location>
ERROR_LOG_DIR_GREP=$1
#grep -e "Running job: job_" -e " ERROR " $1
if [ -z ${ERROR_LOG_DIR_GREP} ]; then
    ERROR_LOG_DIR_GREP=${LOCAL_LOG_DIR}
fi
  errs=`grep -E -i "Error|exception" ${ERROR_LOG_DIR_GREP} | grep -v "Duplicate" | grep -v "Appending value"`
  errs=`echo "${errs}" | sed ':a;N;$!ba;s/\n/; /g'`
#error=$(grep -E -i "error|exception" ${ERROR_LOG_DIR_GREP} | grep -v "Duplicate" | grep -v "Appending value" )
#error=$(echo "${errs}" | sed ':a;N;$!ba;s/\n/; /g' )
echo $errs
exit 0;
