#!/bin/bash

# Author: MANULIFE
# Date: 2017-08-08

# Description:  Copy avsc file to hdfs 

# USAGE: init_kinit.sh  <PRINCIPAL> <KEYTAB> <HADOOP_CONF_PATH>   

JAVA_HOME=/var/lib/ambari-server/resources/jdk1.8.0_112

krb_principal=$1
keytab_file=$2
HADOOP_CONF=$3
KRB5CCNAME=/var/tmp/${krb_principal}.ccache
hdfs_cmd=/bin/hdfs

kinit -kt $keytab_file $krb_principal

