#!/bin/bash

# Author: Manulife
# Date: 2019-05-17

# Description:  Executing Sqoop job from Edge Node

# USAGE: run_sqoop.sh  <PRINCIPAL> <KEYTAB> <HADOOP_CONF_PATH> <SQOOP_JOB_NAME> <SQOOP_TABLE_NAME> <CONNECTION_STRING> <USER_NAME> <PASSWORD_FILE> <WAREHOUSE_DIR> <OUT_DIR> <CLOB_COLS> <BLOB_COLS> <splt_by_col> <no_of_mappers> <boundaryValues> <limit_ingestion_rows> <Ingestion_source>

JAVA_HOME=/var/lib/ambari-server/resources/jdk1.8.0_112

krb_principal=$1
keytab_file=$2
HADOOP_CONF=$3
db_driver=$4
table_name=$5
connect_string=$6
user_name=$7
password_file=$8
warehouse_dir=$9
out_dir=${10}
allColumns=${11}
clob_cols=${12}
blob_cols=${13}
splt_by_col=${14}
no_of_mappers=${15}
boundaryValues=${16}
limit_ingestion_rows=${17}
Ingestion_Source=${18}

echo $krb_principal     is      krb_principal
echo $keytab_file       is      keytab_file
echo $HADOOP_CONF       is      HADOOP_CONF
echo $db_driver         is      db_driver
echo $table_name        is      table_name
echo $connect_string    is      connect_string
echo $user_name         is      user_name
echo $password_file     is      password_file
echo $warehouse_dir     is      warehouse_dir
echo $out_dir           is      out_dir
echo $allColumns        is      allColumns
echo $clob_cols         is      clob_cols
echo $blob_cols         is      blob_cols
echo $splt_by_col       is      splt_by_col
echo $no_of_mappers     is      no_of_mappers
echo $boundaryValues    is      boundaryValues
echo $limit_ingestion_rows is   limit ingestion rows
echo $Ingestion_Source is Ingestion_Source

sqoop_cmd=/usr/hdp/current/sqoop-client/bin/sqoop

sqoop_lob_parm=''

if [ $blob_cols != "null" ];
then
     sqoop_lob_parm="--map-column-hive $blob_cols"
fi;
if [ $clob_cols != "null" ]
then
     sqoop_lob_parm="--map-column-java $clob_cols"
fi;
if [[ $blob_cols != "null"  &&  $clob_cols != "null" ]]
then
     sqoop_lob_parm="--map-column-java $clob_cols --map-column-hive $blob_cols"
fi;

if [[ $limit_ingestion_rows = 'FALSE' ||  $limit_ingestion_rows = 'false' ]];
then
        limit_query=''
else
        limit_query=' rownum < 10 and '
fi;


if [ $no_of_mappers = "null" ];
then
        mappers=1
else
        mappers=$no_of_mappers
fi;

if [ $splt_by_col = "null" ];
then
        split_query=''
else
        split_query=" --split-by $splt_by_col"
fi;

if [ $Ingestion_Source == 'DB' ];
then
        if [ $boundaryValues == 'null' ];
        then
                $sqoop_cmd import -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapreduce.job.name=$table_name -Dmapreduce.map.memory.mb=1024 -Dorg.apache.sqoop.splitter.allow_text_splitter=true --connect $connect_string  --driver $db_driver --username $user_name --password-file $password_file --query "SELECT * FROM $table_name WHERE $limit_query \$CONDITIONS" --delete-target-dir --target-dir $warehouse_dir --outdir $out_dir $split_query --num-mappers $mappers --as-avrodatafile $sqoop_lob_parm

        else
                $sqoop_cmd import -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapreduce.job.name=$table_name -Dmapreduce.map.memory.mb=1024 -Dorg.apache.sqoop.splitter.allow_text_splitter=true --connect $connect_string  --driver $db_driver --username $user_name --password-file $password_file --boundary-query "SELECT $boundaryValues FROM $table_name" --query "SELECT * FROM $table_name WHERE $limit_query \$CONDITIONS" --delete-target-dir --target-dir $warehouse_dir --outdir $out_dir $split_query --num-mappers $mappers --as-avrodatafile $sqoop_lob_parm
        fi;
else
        if [ $boundaryValues == 'null' ];
        then
                $sqoop_cmd import -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapreduce.job.name=$table_name -Dmapreduce.map.memory.mb=1024 -Dorg.apache.sqoop.splitter.allow_text_splitter=true --connect $connect_string  --connection-manager $db_driver --username $user_name --password-file $password_file --query "SELECT * FROM $table_name WHERE $limit_query \$CONDITIONS" --delete-target-dir --target-dir $warehouse_dir --outdir $out_dir $split_query --num-mappers $mappers --as-avrodatafile $sqoop_lob_parm

        else
                $sqoop_cmd import -Dmapreduce.job.classloader=true -Dmapreduce.job.user.classpath.first=true -Dmapreduce.job.name=$table_name -Dmapreduce.map.memory.mb=1024 -Dorg.apache.sqoop.splitter.allow_text_splitter=true --connect $connect_string  --connection-manager $db_driver --username $user_name --password-file $password_file --boundary-query "SELECT $boundaryValues FROM $table_name" --query "SELECT * FROM $table_name WHERE $limit_query \$CONDITIONS" --delete-target-dir --target-dir $warehouse_dir --outdir $out_dir $split_query --num-mappers $mappers --as-avrodatafile $sqoop_lob_parm
        fi;
fi;
