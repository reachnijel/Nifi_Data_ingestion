#!/bin/bash

# Author: MANULIFE
# Date: 2017-08-08

# Description:  Sqoop Master

# USAGE: run_sqoop.sh  <PRINCIPAL> <KEYTAB> <HADOOP_CONF_PATH> <SQOOP_JOB_NAME> <SQOOP_TABLE_NAME> <CONNECTION_STRING> <USER_NAME> <PASSWORD_FILE> <WAREHOUSE_DIR> <OUT_DIR> <CLOB_COLS> <BLOB_COLS> <splt_by_col> <no_of_mappers> <boundaryValues> <limit_ingestion_rows>

echo $1
echo "Start Time: $(date)"
mkdir -p ${18}/sqoop_logs
rm ${18}/sqoop_logs/$5.out
touch ${18}/sqoop_logs/$5.out
rm -r ${10}
nohup sh ${18}/run_sqoop.sh $1 $2 $3 $4 $5 $6 $7 $8 $9 ${10} ${11} ${12} ${13} ${14} ${15} ${16} ${17} &> ${18}/sqoop_logs/$5.out &
current_pid=$$
echo "Sqoop Master Process id: '$current_pid'"
pid=$!
echo "Run Sqoop Process id: '$pid'"
num=240
#echo $num
while [[ $num -gt 0 && ( -z $(grep "Running job: job_" ${18}/sqoop_logs/$5.out) ) ]];do sleep 60;num=$((num-1));done
sqooppid=`ps -eaf | grep org.apache.sqoop.Sqoop | grep $5 | awk '{print $2}'`
echo 'killing sqoop with pid =' $sqooppid
echo "End Time: $(date)"
kill -9 $sqooppid
kill -9 $pid

grep "Running job: job_" ${18}/sqoop_logs/$5.out
