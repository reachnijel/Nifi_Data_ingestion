#!/bin/bash

# Author: MANULIFE
# Date: 2017-08-08

# Description:  Copy avsc file to hdfs

# USAGE: run_sqoop.sh  <PRINCIPAL> <KEYTAB> <HADOOP_CONF_PATH> <AVSC_FILE_PATH> <HDFS_FOLDER>

JAVA_HOME=/var/lib/ambari-server/resources/jdk1.8.0_112

krb_principal=$1
keytab_file=$2
HADOOP_CONF=$3
avsc_file=$4
hdfs_folder=$5
hdfs_file=$6
#KRB5CCNAME=/var/tmp/${krb_principal}.ccache
#kkache=`date +%s.%N`
#KRB5CCNAME=/var/tmp/${krb_principal}${kkache}.ccache
#KRB5CACHE=/tmp/${krb_principal}${kkache}.ccache
cpy_cmd=/bin/hdfs

#kinit -kt $keytab_file $krb_principal
if $(hadoop fs -test -d $hdfs_folder) ; then
$cpy_cmd  dfs -put -f $avsc_file/*.avsc $hdfs_folder$hdfs_file
else
$cpy_cmd  dfs -mkdir -p  $hdfs_folder
$cpy_cmd  dfs -put -f $avsc_file/*.avsc $hdfs_folder$hdfs_file
fi

#rm $KRB5CACHE
