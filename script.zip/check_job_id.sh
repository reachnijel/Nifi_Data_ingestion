#!/bin/bash

# Author: MANULIFE
# Date: 2017-08-08

# Description:  Executing sqoop job from Nifi Node

# USAGE: check_job_id.sh <local_file_absolute_location>

grep -e "Running job: job_" -e " ERROR " $1

exit 0;
